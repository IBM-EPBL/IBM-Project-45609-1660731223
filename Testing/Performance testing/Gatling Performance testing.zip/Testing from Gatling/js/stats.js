var stats = {
    type: "GROUP",
name: "All Requests",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "All Requests",
    "numberOfRequests": {
        "total": "105",
        "ok": "104",
        "ko": "1"
    },
    "minResponseTime": {
        "total": "239",
        "ok": "239",
        "ko": "286"
    },
    "maxResponseTime": {
        "total": "1185",
        "ok": "1185",
        "ko": "286"
    },
    "meanResponseTime": {
        "total": "368",
        "ok": "369",
        "ko": "286"
    },
    "standardDeviation": {
        "total": "261",
        "ok": "262",
        "ko": "0"
    },
    "percentiles1": {
        "total": "275",
        "ok": "275",
        "ko": "286"
    },
    "percentiles2": {
        "total": "286",
        "ok": "286",
        "ko": "286"
    },
    "percentiles3": {
        "total": "1091",
        "ok": "1091",
        "ko": "286"
    },
    "percentiles4": {
        "total": "1152",
        "ok": "1153",
        "ko": "286"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 92,
    "percentage": 88
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 12,
    "percentage": 11
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 1,
    "percentage": 1
},
    "meanNumberOfRequestsPerSecond": {
        "total": "5.526",
        "ok": "5.474",
        "ko": "0.053"
    }
},
contents: {
"req_home-8cf04": {
        type: "REQUEST",
        name: "Home",
path: "Home",
pathFormatted: "req_home-8cf04",
stats: {
    "name": "Home",
    "numberOfRequests": {
        "total": "12",
        "ok": "12",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1017",
        "ok": "1017",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1185",
        "ok": "1185",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "1091",
        "ok": "1091",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "47",
        "ok": "47",
        "ko": "-"
    },
    "percentiles1": {
        "total": "1088",
        "ok": "1088",
        "ko": "-"
    },
    "percentiles2": {
        "total": "1115",
        "ok": "1115",
        "ko": "-"
    },
    "percentiles3": {
        "total": "1167",
        "ok": "1167",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1181",
        "ok": "1181",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 12,
    "percentage": 100
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.632",
        "ok": "0.632",
        "ko": "-"
    }
}
    },"req_home-redirect-1-df14c": {
        type: "REQUEST",
        name: "Home Redirect 1",
path: "Home Redirect 1",
pathFormatted: "req_home-redirect-1-df14c",
stats: {
    "name": "Home Redirect 1",
    "numberOfRequests": {
        "total": "12",
        "ok": "12",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "257",
        "ok": "257",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "348",
        "ok": "348",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "286",
        "ok": "286",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "26",
        "ok": "26",
        "ko": "-"
    },
    "percentiles1": {
        "total": "279",
        "ok": "279",
        "ko": "-"
    },
    "percentiles2": {
        "total": "286",
        "ok": "286",
        "ko": "-"
    },
    "percentiles3": {
        "total": "339",
        "ok": "339",
        "ko": "-"
    },
    "percentiles4": {
        "total": "346",
        "ok": "346",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 12,
    "percentage": 100
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.632",
        "ok": "0.632",
        "ko": "-"
    }
}
    },"req_search-13348": {
        type: "REQUEST",
        name: "Search",
path: "Search",
pathFormatted: "req_search-13348",
stats: {
    "name": "Search",
    "numberOfRequests": {
        "total": "12",
        "ok": "12",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "263",
        "ok": "263",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "317",
        "ok": "317",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "277",
        "ok": "277",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "15",
        "ok": "15",
        "ko": "-"
    },
    "percentiles1": {
        "total": "272",
        "ok": "272",
        "ko": "-"
    },
    "percentiles2": {
        "total": "279",
        "ok": "279",
        "ko": "-"
    },
    "percentiles3": {
        "total": "307",
        "ok": "307",
        "ko": "-"
    },
    "percentiles4": {
        "total": "315",
        "ok": "315",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 12,
    "percentage": 100
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.632",
        "ok": "0.632",
        "ko": "-"
    }
}
    },"req_select-e0626": {
        type: "REQUEST",
        name: "Select",
path: "Select",
pathFormatted: "req_select-e0626",
stats: {
    "name": "Select",
    "numberOfRequests": {
        "total": "12",
        "ok": "12",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "252",
        "ok": "252",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "296",
        "ok": "296",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "275",
        "ok": "275",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "13",
        "ok": "13",
        "ko": "-"
    },
    "percentiles1": {
        "total": "275",
        "ok": "275",
        "ko": "-"
    },
    "percentiles2": {
        "total": "284",
        "ok": "284",
        "ko": "-"
    },
    "percentiles3": {
        "total": "291",
        "ok": "291",
        "ko": "-"
    },
    "percentiles4": {
        "total": "295",
        "ok": "295",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 12,
    "percentage": 100
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.632",
        "ok": "0.632",
        "ko": "-"
    }
}
    },"req_page-0-bd5d5": {
        type: "REQUEST",
        name: "Page 0",
path: "Page 0",
pathFormatted: "req_page-0-bd5d5",
stats: {
    "name": "Page 0",
    "numberOfRequests": {
        "total": "12",
        "ok": "12",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "256",
        "ok": "256",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "285",
        "ok": "285",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "270",
        "ok": "270",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "8",
        "ok": "8",
        "ko": "-"
    },
    "percentiles1": {
        "total": "271",
        "ok": "271",
        "ko": "-"
    },
    "percentiles2": {
        "total": "275",
        "ok": "275",
        "ko": "-"
    },
    "percentiles3": {
        "total": "283",
        "ok": "283",
        "ko": "-"
    },
    "percentiles4": {
        "total": "285",
        "ok": "285",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 12,
    "percentage": 100
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.632",
        "ok": "0.632",
        "ko": "-"
    }
}
    },"req_page-1-dffde": {
        type: "REQUEST",
        name: "Page 1",
path: "Page 1",
pathFormatted: "req_page-1-dffde",
stats: {
    "name": "Page 1",
    "numberOfRequests": {
        "total": "12",
        "ok": "12",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "251",
        "ok": "251",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "297",
        "ok": "297",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "271",
        "ok": "271",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "12",
        "ok": "12",
        "ko": "-"
    },
    "percentiles1": {
        "total": "271",
        "ok": "271",
        "ko": "-"
    },
    "percentiles2": {
        "total": "276",
        "ok": "276",
        "ko": "-"
    },
    "percentiles3": {
        "total": "289",
        "ok": "289",
        "ko": "-"
    },
    "percentiles4": {
        "total": "295",
        "ok": "295",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 12,
    "percentage": 100
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.632",
        "ok": "0.632",
        "ko": "-"
    }
}
    },"req_page-2-9cd0e": {
        type: "REQUEST",
        name: "Page 2",
path: "Page 2",
pathFormatted: "req_page-2-9cd0e",
stats: {
    "name": "Page 2",
    "numberOfRequests": {
        "total": "12",
        "ok": "12",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "239",
        "ok": "239",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "289",
        "ok": "289",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "273",
        "ok": "273",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "14",
        "ok": "14",
        "ko": "-"
    },
    "percentiles1": {
        "total": "276",
        "ok": "276",
        "ko": "-"
    },
    "percentiles2": {
        "total": "284",
        "ok": "284",
        "ko": "-"
    },
    "percentiles3": {
        "total": "288",
        "ok": "288",
        "ko": "-"
    },
    "percentiles4": {
        "total": "289",
        "ok": "289",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 12,
    "percentage": 100
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.632",
        "ok": "0.632",
        "ko": "-"
    }
}
    },"req_page-3-cdc73": {
        type: "REQUEST",
        name: "Page 3",
path: "Page 3",
pathFormatted: "req_page-3-cdc73",
stats: {
    "name": "Page 3",
    "numberOfRequests": {
        "total": "12",
        "ok": "12",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "246",
        "ok": "246",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "290",
        "ok": "290",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "273",
        "ok": "273",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "13",
        "ok": "13",
        "ko": "-"
    },
    "percentiles1": {
        "total": "275",
        "ok": "275",
        "ko": "-"
    },
    "percentiles2": {
        "total": "282",
        "ok": "282",
        "ko": "-"
    },
    "percentiles3": {
        "total": "290",
        "ok": "290",
        "ko": "-"
    },
    "percentiles4": {
        "total": "290",
        "ok": "290",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 12,
    "percentage": 100
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.632",
        "ok": "0.632",
        "ko": "-"
    }
}
    },"req_form-d359c": {
        type: "REQUEST",
        name: "Form",
path: "Form",
pathFormatted: "req_form-d359c",
stats: {
    "name": "Form",
    "numberOfRequests": {
        "total": "3",
        "ok": "3",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "262",
        "ok": "262",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "274",
        "ok": "274",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "267",
        "ok": "267",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "5",
        "ok": "5",
        "ko": "-"
    },
    "percentiles1": {
        "total": "264",
        "ok": "264",
        "ko": "-"
    },
    "percentiles2": {
        "total": "269",
        "ok": "269",
        "ko": "-"
    },
    "percentiles3": {
        "total": "273",
        "ok": "273",
        "ko": "-"
    },
    "percentiles4": {
        "total": "274",
        "ok": "274",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 3,
    "percentage": 100
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.158",
        "ok": "0.158",
        "ko": "-"
    }
}
    },"req_post-03d94": {
        type: "REQUEST",
        name: "Post",
path: "Post",
pathFormatted: "req_post-03d94",
stats: {
    "name": "Post",
    "numberOfRequests": {
        "total": "3",
        "ok": "3",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "265",
        "ok": "265",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "297",
        "ok": "297",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "284",
        "ok": "284",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "14",
        "ok": "14",
        "ko": "-"
    },
    "percentiles1": {
        "total": "291",
        "ok": "291",
        "ko": "-"
    },
    "percentiles2": {
        "total": "294",
        "ok": "294",
        "ko": "-"
    },
    "percentiles3": {
        "total": "296",
        "ok": "296",
        "ko": "-"
    },
    "percentiles4": {
        "total": "297",
        "ok": "297",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 3,
    "percentage": 100
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.158",
        "ok": "0.158",
        "ko": "-"
    }
}
    },"req_post-redirect-1-1713a": {
        type: "REQUEST",
        name: "Post Redirect 1",
path: "Post Redirect 1",
pathFormatted: "req_post-redirect-1-1713a",
stats: {
    "name": "Post Redirect 1",
    "numberOfRequests": {
        "total": "3",
        "ok": "2",
        "ko": "1"
    },
    "minResponseTime": {
        "total": "260",
        "ok": "260",
        "ko": "286"
    },
    "maxResponseTime": {
        "total": "286",
        "ok": "268",
        "ko": "286"
    },
    "meanResponseTime": {
        "total": "271",
        "ok": "264",
        "ko": "286"
    },
    "standardDeviation": {
        "total": "11",
        "ok": "4",
        "ko": "0"
    },
    "percentiles1": {
        "total": "268",
        "ok": "264",
        "ko": "286"
    },
    "percentiles2": {
        "total": "277",
        "ok": "266",
        "ko": "286"
    },
    "percentiles3": {
        "total": "284",
        "ok": "268",
        "ko": "286"
    },
    "percentiles4": {
        "total": "286",
        "ok": "268",
        "ko": "286"
    },
    "group1": {
    "name": "t < 800 ms",
    "htmlName": "t < 800 ms",
    "count": 2,
    "percentage": 67
},
    "group2": {
    "name": "800 ms <= t < 1200 ms",
    "htmlName": "t ≥ 800 ms <br> t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t ≥ 1200 ms",
    "htmlName": "t ≥ 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "htmlName": "failed",
    "count": 1,
    "percentage": 33
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.158",
        "ok": "0.105",
        "ko": "0.053"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
